"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.helloo = void 0;
const helloo = async (_event) => {
    return {
        statusCode: 200,
        body: JSON.stringify({
            message: 'Hello from Lambda! Successfully deployed Dev Branch Ngoh'
        }),
    };
};
exports.helloo = helloo;
